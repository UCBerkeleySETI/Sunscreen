#!/bin/sh
#v. 11 Oct 2018
#This script processes the complete stellar isochrone files from CMD-3.0 into a form that can 
#be used by Sunscreen.
#This version does NOT include the terminating post-AGB point on the isochrones, which can
#otherwise be among the brightest and bluest stars in a galaxy with old stars.  From the CMD-3.0
#FAQ (May 2018), those points on the isochrones are meant to signal the end of the isochrone for
#use with some population synthesis codes.  The fact that log L = -9.999 is meant to signal that
#they are spurious.  PARSEC in general does NOT include post-AGB evolution, though it does include
#TP-AGB evolution.

#Put the CMD-3.0 isochrone grid files (as downloaded from the web interface) in IsochroneFileList
#	They are assumed to be in the same directory as this script, which should be "CMD-Isochrones"
#	if they are to be used by Sunscreen.
#	Note that the isochrones for a given metallicity can be split into several files.  List them all
#	with their correct metallicity format and with unique index integers, and this will still work.
#Put their respective metallicities, in order, in logZlist.
#	log Z is measured with respect to Solar metallicity (Z_sun = 0.0152 in the files I use),
#   so Solar metallicity would be listed as 0.0.
#Then list integers from 0 to N-1 in iList, where N is the number of files to process.

# #IsochroneFileList=(output811597023232.dat output793733978950.dat output9147665071.dat output631465745464.dat output526269336770.dat  output839348722788.dat)
# #logZList=(0.0 0.0 -1.0 -1.0 0.301 0.301)
# #iList="0 1 2 3 4 5"

# IsochroneFileList=(output582756141041.dat output262746523673.dat output382057812837.dat)
# logZList=(0.0 -1.0 0.301)
# iList=$(seq 0 2)

IsochroneFileList=(output811597023232.dat output793733978950.dat output582756141041.dat output9147665071.dat output631465745464.dat output262746523673.dat output526269336770.dat output839348722788.dat output382057812837.dat)
logZList=(0.0 0.0 0.0 -1.0 -1.0 -1.0 0.301 0.301 0.301)
iList=$(seq 0 8)

PostAGBStage=9

for i in $iList
do
	logZ=${logZList[$i]}
	Isochrone=${IsochroneFileList[$i]}

	echo $i $logZ $Isochrone
	tList=$(grep -v "#" $Isochrone | cut -d ' ' -f 2 | sort -g | uniq)
	#Prints to check that the metallicities in logZList correspond to the actual
	#isochrone metallicity.
	ZInFile=$(grep -v "#" output582756141041.dat | cut -d ' ' -f 1 | head -n 1)

	echo $logZ $Isochrone
	#echo $tList

	for t in $tList
	do
		#The isochrones are NOT exactly spaced by dlog t = 0.01, for some reason -- probably
		#the low precision of the times listed in column 2.  I have checked that rounding
		#to two digits in log t ensures that each log t from 6.50 to 10.12 is included once
		#and only once.
		OutFileName=$(awk 'BEGIN{printf "Isochrone.logZ%+.2f.logt%+.2f.txt\n", '$logZ', log('$t')/log(10.0)}')
		echo $t $ZInFile $OutFileName
		
		if [ -e "$OutFileName" ]
		then
			rm $OutFileName
		fi	
		
		#Format of CMD files:
		#--------------------
		#Zini Age Mini  Mass   logL    logTe  logg  label   McoreTP C_O  period0 period1 pmode  Mloss  tau1m   X   Y   Xc  Xn  Xo  Cexcess  Z   mbolmag  Umag    Bmag    Vmag    Rmag    Imag    Jmag    Hmag    Kmag
		#Want M_ini to scale by IMF
		
		#L = sigma T^4 * 4 pi R_1^2 ==> R_1 = sqrt(L / (4 pi sigma T^4))
		#g = G M / R_2^2 ==> R_2 = sqrt(G M / g)
		#In most cases, the different ways of estimating R vary by <~ 0.2%.  However, logL seems to go to -9.999
		#during white dwarf/planetary nebula phases (the last step) so that logR goes to ~5 (1 km).  Thus, I'll
		#use surface gravity to calculate R.
		#I still calculate L this way for consistency, but 
		
		awk 'BEGIN{log10 = log(10.0); 
			 GNMSun = 6.674e-8 * 1.989e33;
			 ZSun = 0.0152}
			 (($2 == '$t')&&($8 < '$PostAGBStage')){logZ = log($1 / ZSun)/log10; 
						  t = $2;
						  M0 = $3;
						  M = $4;
						  logL = $5;
						  logTeff = $6;
						  logg = $7;
						  logR = 0.5 * (log(GNMSun * M)/log10 - logg);
						  Stage = $8;
						  printf "%e %.12f  %f %+f %f %f %+f %d  %+f\n", t, M0, M, logL, logTeff, logR, logg, Stage, logZ;}' $Isochrone >> $OutFileName
		
	done
done
