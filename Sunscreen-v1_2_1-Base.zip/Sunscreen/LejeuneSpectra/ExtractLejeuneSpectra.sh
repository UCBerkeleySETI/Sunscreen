#!/bin/sh

ModelFileList=(lcbp00.cor lcbm10.cor lcbp03.cor)
logZList=(0.0 -1.0 0.3)
jList="0 1 2"

cat ${ModelFileList[0]} | head -n 153 | tr -s ' ' | tr ' ' '\n' | tr -s '\n' | awk '(NR > 1){printf "%e\n", $1 * 1e-7}' > lambda-LejeuneSpectra.txt

Nlambda=$(cat lambda-LejeuneSpectra.txt | wc | awk '{print $2}')
echo $Nlambda

for j in $jList
do
	logZ=${logZList[$j]}
	ModelFile=${ModelFileList[$j]}

	NModels=$(wc $ModelFile | awk '{print ($1-153)/176}')
	iList=$(awk 'BEGIN{for (i = 0; i < '$NModels'; i++){print i}}')

	for i in $iList
	do
		ModelParams=$(cat $ModelFile | awk '(NR == 154 + '$i'*176){print}')
		#echo $ModelParams
		ModelArray=($ModelParams)
		Teff=${ModelArray[1]}
		logg=${ModelArray[2]}
		logZ=${ModelArray[3]}
		SpectrumFile=$(printf "LejeuneSpectrum.logZ%+.2f.Teff+%d.logg%+.2f" $logZ $Teff $logg)
		
		echo $Teff $logg $logZ $SpectrumFile

		#According to the README, F_nu = 4 * H_nu.
		#But looking at RL79, H_nu = 1/2 * Int(-1 <= mu <= 1) mu I dmu
		#At the surface, I ~ I* for -1 <= mu <= 0 and 0 for mu > 0, so 
		#	H_nu ~ 1/2 * I* Int(-1 <= mu <= 0) mu dmu
		#   H_nu ~ I*/4
		#As F_nu = 2 pi Int(-1 <= mu <= 1) mu I dmu,
		#   F_nu ~ pi I* ~ 4 pi H_nu
		cat $ModelFile | awk 'BEGIN{lFirst = 155 + '$i' * 176;
											lLast = 154 + ('$i' + 1) * 176 - 1;}
											((NR >= lFirst)&&(NR <= lLast)){print}' | tr -s ' ' | tr ' ' '\n' | tr -s '\n' | awk '(NR > 1){printf "%e\n", $1 * 4 * 3.14159265358979}' | paste lambda-LejeuneSpectra.txt - -d ' ' > $SpectrumFile #| tee $SpectrumFile
		unset ModelArray
	done
done


