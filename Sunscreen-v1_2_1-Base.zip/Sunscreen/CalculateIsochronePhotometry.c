#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#define NT 68
#define NG 19
#define NLam 1221

#define NZ 3
#define NtIso 614

#define NFilt 48

#define TRUE 1
#define FALSE 0

typedef struct
{
   double t;
   double M0;
   double M;
   double L;
   double Teff;
   double R;
   double logg;
   double A;
   int Stage;
   double Z;
} StellarData;

typedef struct
{
	int t0;
	int g0;
	int g1;
	double f00;
	double f01;
	double f10;
	double f11;
} sInterpConstants;

double pi = 3.14159265358979323846264;
double kB = 1.381e-16;
double c = 2.998e10;
double hPlanck = 6.626e-27;
double LSun = 3.826e33;
double sigmaSB = 5.671e-5;
double pc = 3.0857e18;
double Watt = 1e7;

enum StageList {prems, ms, sgb, rgb, cehb1, cehb2, cehb3, eagb, tpagb, remnant};

int CountLinesInFile (FILE *f);
void ReadLamList (char *FileName, double *Spectrum);
void ReadSpectrum (char *FileName, double *Spectrum);
void ReadIsochrone (char *FileName, StellarData **Isochrone, int *NMasses);

double BnuPlanck (double lambda, double T);
double FnuPlanck (double lambda, double T);

int BinarySearchForFirstGTE (int N, double *Table, double x);

double MBol (double LBol);

void ReadFilterN0 (char *FileName, int *NFLam, double **Lambda, double **N0);
double InterpolatedN0 (double lambda, int NFLam, double *FilterLambda, double *FilterN0);

void PrintHeader (FILE *OutFile, char ColumnNames[NFilt][100]);


int main (void)
{
	int z, i, j, k, l;
	int i_Filter, i_lambda;
	
	char FilterName[NFilt][100] = {"FUV", "NUV", \
								   "U_JC", "B_JC", "V_JC", "R_JC", "I_JC", \
	                               "u_SDSS", "g_SDSS", "r_SDSS", "i_SDSS", "z_SDSS", \
								   "g_DES", "r_DES", "i_DES", "z_DES", "Y_DES", \
								   "g_PS1", "r_PS1", "i_PS1", "z_PS1", "y_PS1", "w_PS1", \
	                               "u_LSST", "g_LSST", "r_LSST", "i_LSST", "z_LSST", "y_LSST", \
								   "G_Gaia", "GBP_Gaia", "GRP_Gaia",  \
								   "J_2MASS", "H_2MASS", "Ks_2MASS", \
								   "Z_UKIRT", "Y_UKIRT", "J_UKIRT", "H_UKIRT", "K_UKIRT", \
								   "IRAC-1", "IRAC-2", "IRAC-3", "IRAC-4", \
								   "W1_WISE", "W2_WISE", "W3_WISE", "W4_WISE"};
	char FilterN0Name[255];
	
	int NFLam;
	double *FilterLambda;
	double *FilterN0;
	double *FilterKernel[NFilt];
	
	double lambda_Blue, lambda_Red;
	double Integrand_Blue, Integrand_Red;
	int i_FilterLambda_Blue, i_FilterLambda_Red;
	int i_FilterLambda;
	
	double Magnitudes[NFilt];
	
	double IntegrandLo, IntegrandHi;
	double RatioSum;
	
	double t;
	double logtIso;
	double logtIsoMin = 4.00; //6.50;
	double logtIsoMax = 10.13; //10.12;
	double dlogtIso = 0.01;
	double logtIsoList[NtIso];
	StellarData *Isochrone;
	double ThisStellarSpectrum[NLam];
	
	double logZ[NZ] = {0.00, -1.00, 0.301};
	
	int NMasses;
	
	double DFactor_AbsMagnitude = 4.0 * pi * 100.0 * pc * pc;
	
	double HotSpectrum[NLam];
	double ColdSpectrum[NLam];
	
	int Ng;
	int	iT;
	int igCold, igHot;
	double fTCold, fTHot;
	double fgColdLo, fgColdHi, fgHotLo, fgHotHi;
	double f00, f01, f10, f11;

	double MStar;
	double TStar, loggStar;
	
	double LBol;
	
	double lamList[NLam];
	double dnuList[NLam];
	double FullTGrid[NT] = {2000, 2200, 2500, 2800, 3000,\
					  3200, 3350, 3500, 3750, 4000,\
 				      4250, 4500, 4750, 5000, 5250,\
					  5500, 5750, 6000, 6250, 6500,\
					  6750, 7000, 7250, 7500, 7750,\
					  8000, 8250, 8500, 8750, 9000,\
					  9250, 9500, 9750, 10000, 10500,\
					  11000, 11500, 12000, 12500, 13000,\
					  14000, 15000, 16000, 17000, 18000,\
					  19000, 20000, 21000, 22000, 23000,\
					  24000, 25000, 26000, 27000, 28000,\
					  29000, 30000, 31000, 32000, 33000,\
					  34000, 35000, 37500, 40000, 42500,\
					  45000, 47500, 50000};
	double FullloggGrid[NG] = {-1.02, -0.70, -0.51, -0.29, +0.00,\
	                      +0.28, +0.50, +0.60, +0.87, +1.00,\
						  +1.50, +2.00, +2.50, +3.00, +3.50,\
						  +4.00, +4.50, +5.00, +5.50};
	int GridModelExists[NT][NG];
	int TExists[NT];
	int nTForZ;
	int *ngAtT;
	double *TGrid;
	double **loggGrid;
	double ***ModelSpectrum;
	char ModelSpectrumName[255];
	
	char MagnitudeName[255];
	char IsochroneName[255];
	FILE *InFile;
	FILE *OutFile;
	
	
	//Wavelength read-in
	//==================
	for (j = 0; j < NtIso; j++) logtIsoList[j] = logtIsoMin + (double) j * dlogtIso;
	ReadLamList ("LejeuneSpectra/lambda-LejeuneSpectra.txt", lamList);

	for (l = 0; l < NLam; l++) 
	{
		if (l > 0) dnuList[l] = c / lamList[l - 1] - c / lamList[l];
	}
	
	//Filter kernel calculation
	//=========================
	for (i_Filter = 0; i_Filter < NFilt; i_Filter++)
	{
		//This requires that all {Screened, Cumulative}Spectra have the same fixed lambda
		sprintf (FilterN0Name, "FilterResponses/PhotonZeroPoint-%s.txt", FilterName[i_Filter]);
		
		printf ("%d %s\n", i_Filter, FilterN0Name);
		
		ReadFilterN0 (FilterN0Name, &NFLam, &FilterLambda, &FilterN0);
		
		FilterKernel[i_Filter] = calloc (NLam, sizeof(double));
		//FilterKernel is convolved with the spectrum to calculate the magnitudes.
		i_FilterLambda_Blue = i_FilterLambda_Red = 0;
		for (i_lambda = 0; i_lambda < NLam; i_lambda++)
		{
			lambda_Blue = (i_lambda == 0) ? lamList[0] : (0.5 * (lamList[i_lambda - 1] + lamList[i_lambda]));
			lambda_Red = (i_lambda == NLam - 1) ? lamList[i_lambda] : (0.5 * (lamList[i_lambda + 1] + lamList[i_lambda]));
			
			//calloc ensures FilterKernel set to 0.
			if (lambda_Red <= FilterLambda[0]) continue; 
			if (lambda_Blue >= FilterLambda[NFLam - 1]) continue;

			//Index of first wavelength in FilterLambda >= lambda_Blue
			while ((lambda_Blue > FilterLambda[i_FilterLambda_Blue]) && (i_FilterLambda_Blue < NFLam - 1)) i_FilterLambda_Blue++;
			while ((lambda_Red > FilterLambda[i_FilterLambda_Red]) && (i_FilterLambda_Red < NFLam - 1)) i_FilterLambda_Red++;

			if (i_FilterLambda_Red == i_FilterLambda_Blue)
			{
				//Filter wavelengths coarser than model spectrum wavelengths
				FilterKernel[i_Filter][i_lambda] = InterpolatedN0 (lamList[i_lambda], NFLam, FilterLambda, FilterN0) / (hPlanck * lamList[i_lambda] * DFactor_AbsMagnitude);
			}
			else
			{
				//Wavelength-weighted
				Integrand_Blue = InterpolatedN0 (lambda_Blue, NFLam, FilterLambda, FilterN0) / (hPlanck * lambda_Blue * DFactor_AbsMagnitude);
				Integrand_Red = FilterN0[i_FilterLambda_Blue] / (hPlanck * FilterLambda[i_FilterLambda_Blue] * DFactor_AbsMagnitude);
				
				FilterKernel[i_Filter][i_lambda] = 0.5 * (Integrand_Blue + Integrand_Red) * (FilterLambda[i_FilterLambda_Blue] - lambda_Blue);
				
				Integrand_Blue = Integrand_Red;
				
				for (i_FilterLambda = i_FilterLambda_Blue; i_FilterLambda < i_FilterLambda_Red - 1; i_FilterLambda++)
				{			
					Integrand_Red = FilterN0[i_FilterLambda + 1] / (hPlanck * FilterLambda[i_FilterLambda + 1] * DFactor_AbsMagnitude);
					
					FilterKernel[i_Filter][i_lambda] += 0.5 * (Integrand_Blue + Integrand_Red) * (FilterLambda[i_FilterLambda + 1] - FilterLambda[i_FilterLambda]);	
					
					Integrand_Blue = Integrand_Red;
				}
				
				Integrand_Red = InterpolatedN0 (lambda_Red, NFLam, FilterLambda, FilterN0) / (hPlanck * lambda_Red * DFactor_AbsMagnitude);

				FilterKernel[i_Filter][i_lambda] += 0.5 * (Integrand_Blue + Integrand_Red) * (lambda_Red - FilterLambda[i_FilterLambda_Red - 1]);
				
				FilterKernel[i_Filter][i_lambda] /= (lambda_Red - lambda_Blue); 
			}
		}
				
		free (FilterLambda);
		free (FilterN0);
	}
	

	//Main loop
	//=========
	for (z = 0; z < NZ; z++)
	{
		//Do metallicity loop first, since both stellar spectra and isochrones
		//depend on it, and need to be read in for each metallicity.
		
		//Stellar spectra for individual stars at grid points
		//===================================================
		nTForZ = 0;
		for (i = 0; i < NT; i++)
		{
			TExists[i] = FALSE;
			for (j = 0; j < NG; j++)
			{
				sprintf (ModelSpectrumName, "LejeuneSpectra/LejeuneSpectrum.logZ%+.2f.Teff+%.0f.logg%+.2f", logZ[z], FullTGrid[i], FullloggGrid[j]);
				InFile = fopen (ModelSpectrumName, "r");
				if (InFile) 
				{
					GridModelExists[i][j] = TRUE; 
					fclose(InFile);
					TExists[i] = TRUE;
				} 
				else 
				{
					GridModelExists[i][j] = FALSE;
				}
			}
			nTForZ += TExists[i];
		}
		
		ngAtT = calloc (nTForZ, sizeof(int));
		TGrid = calloc (nTForZ, sizeof(double));
		loggGrid = calloc (nTForZ, sizeof(double*));
		ModelSpectrum = calloc (nTForZ, sizeof(double**));
		
		i = 0;
		for (iT = 0; iT < NT; iT++)
		{
			if (TExists[iT] == FALSE) continue;
			TGrid[i] = FullTGrid[iT];
	
			for (j = 0; j < NG; j++) ngAtT[i] += GridModelExists[iT][j];

			loggGrid[i] = calloc (NG, sizeof(double));
			ModelSpectrum[i] = calloc (ngAtT[i], sizeof(double*));

			k = 0;
			for (j = 0; j < NG; j++)
			{
				if (GridModelExists[iT][j] == TRUE)
				{
					ModelSpectrum[i][k] = calloc (NLam, sizeof(double));
					
					loggGrid[i][k] = FullloggGrid[j];
					sprintf (ModelSpectrumName, "LejeuneSpectra/LejeuneSpectrum.logZ%+.2f.Teff+%.0f.logg%+.2f", logZ[z], TGrid[i], FullloggGrid[j]);
					printf ("%s\n", ModelSpectrumName);
					ReadSpectrum (ModelSpectrumName, ModelSpectrum[i][k]);
					k++;
				}
				if (k >= ngAtT[i]) break;
			}
			i++;
		}
		
		//Isochronic stellar spectra
		//==========================
		for (j = 0; j < NtIso; j++)
		{
	
			//Isochrone read-in
			sprintf (IsochroneName, "CMD-Isochrones/Isochrone.logZ%+.2f.logt+%.2f.txt", logZ[z], logtIsoList[j]);
			sprintf (MagnitudeName, "CMD-Isochrones/IsochroneMagnitudes.logZ%+.2f.logt+%.2f.txt", logZ[z], logtIsoList[j]);
			ReadIsochrone (IsochroneName, &Isochrone, &NMasses);
	
			OutFile = fopen (MagnitudeName, "w");	
			PrintHeader (OutFile, FilterName);

			printf ("%d %e  %d  %s %s\n", j, Isochrone[0].t, NMasses, IsochroneName, MagnitudeName);
			for (i = 0; i < NMasses; i++)
			{
				TStar = Isochrone[i].Teff;
				MStar = Isochrone[i].M0;

				if ((TStar < TGrid[0]) || (TStar > TGrid[nTForZ - 1]))
				{
					iT = -1;
					igCold = igHot = -1;
					fTCold = fTHot = fgColdLo = fgColdHi = fgHotLo = fgHotHi = 0.0;
				}
				else
				{
					loggStar = Isochrone[i].logg;
					for (iT = 0; iT < nTForZ - 1; iT++) {if (TGrid[iT + 1] > TStar){break;}}
					
					fTCold = (TStar - TGrid[iT]) / (TGrid[iT + 1] - TGrid[iT]);
					fTHot = (TGrid[iT + 1] - TStar) / (TGrid[iT + 1] - TGrid[iT]);
					
					Ng = ngAtT[iT];
					if (loggStar <= loggGrid[iT][0]) 
					{
						//These need to be flipped from their "real" ordering.
						//(Because when doing the linear interpolation, f(x_Hi)
						//is multiplied by the "Lo" coefficient (x - x_Lo)/(x_Hi - x_Lo),
						//and vice-versa.)
						
						//This way handles the case where Ng = 1 for iT + 1.
						igCold = -1;
						fgColdLo = 1.0;
						fgColdHi = 0.0;
					}
					else if (loggStar >= loggGrid[iT][Ng - 1])
					{
						igCold = Ng - 2;
						fgColdLo = 1.0; 
						fgColdHi = 0.0;	
					}
					else
					{
						for (igCold = 0; igCold < Ng - 1; igCold++) {if (loggGrid[iT][igCold + 1] > loggStar) {break;}}
						
						fgColdLo = (loggStar - loggGrid[iT][igCold]) / (loggGrid[iT][igCold + 1] - loggGrid[iT][igCold]);
						fgColdHi = (loggGrid[iT][igCold + 1] - loggStar) / (loggGrid[iT][igCold + 1] - loggGrid[iT][igCold]);
					}	

					Ng = ngAtT[iT + 1];
					if (loggStar <= loggGrid[iT + 1][0]) 
					{
						//These need to be flipped from their "real" ordering.
						//This way handles the case where Ng = 1 for iT + 1.
						igHot = -1;
						fgHotLo = 1.0;
						fgHotHi = 0.0;
					}
					else if (loggStar >= loggGrid[iT + 1][Ng - 1])
					{
						igHot = Ng - 2;
						fgHotLo = 1.0; 
						fgHotHi = 0.0; 	
					}
					else
					{
						//g[ig] <= gStar < g[ig + 1]
						for (igHot = 0; igHot < Ng - 1; igHot++) {if (loggGrid[iT + 1][igHot + 1] > loggStar) {break;}}
						
						fgHotLo = (loggStar - loggGrid[iT + 1][igHot]) / (loggGrid[iT + 1][igHot + 1] - loggGrid[iT + 1][igHot]);
						fgHotHi = (loggGrid[iT + 1][igHot + 1] - loggStar) / (loggGrid[iT + 1][igHot + 1] - loggGrid[iT + 1][igHot]);	
						
					}
				}
				
				f00 = fTHot * fgColdHi;
				f01 = fTHot * fgColdLo;
				f10 = fTCold * fgHotHi;
				f11 = fTCold * fgHotLo;

				LBol = 0.0;				
				for (l = 0; l < NLam; l++)
				{
					if (iT < 0)
					{
						ThisStellarSpectrum[l] = FnuPlanck (lamList[l], Isochrone[i].Teff) * Isochrone[i].A;
					}
					else
					{
						ThisStellarSpectrum[l] = 0.0;

						if (igCold >= 0) ThisStellarSpectrum[l] += f00 * ModelSpectrum[iT][igCold][l];
						if (igCold >= -1) ThisStellarSpectrum[l] += f01 * ModelSpectrum[iT][igCold + 1][l];					
						if (igHot >= 0) ThisStellarSpectrum[l] += f10 * ModelSpectrum[iT + 1][igHot][l];					
						if (igHot >= -1) ThisStellarSpectrum[l] += f11 * ModelSpectrum[iT + 1][igHot + 1][l];

						ThisStellarSpectrum[l] *= Isochrone[i].A;
					}
					if (l > 1) LBol += 0.5 * (ThisStellarSpectrum[l] + ThisStellarSpectrum[l - 1]) * dnuList[l];
				}
				
				//Stellar magnitude calculation
				//=============================
				fprintf (OutFile, "%e %.12f %e  %f  ", logtIsoList[j], MStar, log10(LBol / LSun), MBol(LBol));

				for (k = 0; k < NFilt; k++)
				{
					RatioSum = 0.0;
					for (l = 0; l < NLam - 1; l++)
					{
						//Int dN/(dt dnu) * T(nu) dnu = Int dE/(dt dnu) * 1/(h nu) * T(nu) dnu
						//                            = Int dE/(dt dnu) * 1/(h lambda) * T(lambda) * dlambda
						//since dln nu = dln lambda

						//ThisStellarSpectrum is in dL/dnu
						IntegrandLo = ThisStellarSpectrum[l + 1] * FilterKernel[k][l + 1];
						IntegrandHi = ThisStellarSpectrum[l] * FilterKernel[k][l];
						RatioSum += 0.5 * (IntegrandHi + IntegrandLo) * (lamList[l + 1] - lamList[l]);
					}
					Magnitudes[k] = -2.5 * log10(RatioSum);
					fprintf (OutFile, "%f ", Magnitudes[k]);
				}
				fprintf (OutFile, "\n");
			}
			
			fclose (OutFile);
			
			free (Isochrone);
		}
		for (i = 0; i < nTForZ; i++) {for (j = 0; j < ngAtT[i]; j++) {free (ModelSpectrum[i][j]);} free (loggGrid[i]); free(ModelSpectrum[i]);}
		free (ModelSpectrum);
		free (loggGrid);
		free (TGrid);
		free (ngAtT);
	}
	
	for (j = 0; j < NFilt; j++) 
	{
		//free(FilterLambda[j]); 
		//free(FilterN0[j]);
		free (FilterKernel[j]);
	}

	return 0;
}

int CountLinesInFile (FILE *f)
{
	int n = 0;
	char c;
	
	if (f == NULL) {return 0;}
	//http://stackoverflow.com/questions/4278845/what-is-the-easiest-way-to-count-the-newlines-in-an-ascii-file
    while ((c=fgetc(f)) != EOF) {if (c == '\n') {n++;}}
    rewind (f);

	return n;
} 

void ReadIsochrone (char *FileName, StellarData **Isochrone, int *NMasses)
{
	int i;
	FILE *InFile;
	int iTemp;
	double t, M0, M, logL, logTeff, logR, logg, logZ;
	int Stage;

	InFile = fopen (FileName, "r");	
	(*NMasses) = CountLinesInFile (InFile);
	//printf ("%s %d\n", FileName, *NAges);
	
	*Isochrone = calloc (*NMasses, sizeof(StellarData));
	
	for (i = 0; i < (*NMasses); i++)
	{
		fscanf (InFile, "%le %lf  %lf %lf %lf %lf %lf %d  %lf\n", &t, &M0, &M, &logL, &logTeff, &logR, &logg, &Stage, &logZ);
		(*Isochrone)[i].t = t;
		(*Isochrone)[i].M0 = M0;
		(*Isochrone)[i].M = M;
		(*Isochrone)[i].Teff = pow(10.0, logTeff);
		(*Isochrone)[i].R = pow(10.0, logR);
		(*Isochrone)[i].logg = logg;
		(*Isochrone)[i].A = 4.0 * pi * pow(10.0, 2.0 * logR);
		//The log L = -9.999 entries actually make up ~10% of the luminosity
		//of older galaxies, because of their relatively high actual luminosities
		//and a plateau of ~1.90 M_sun stars at this log L at 1.74 Gyr (10^9.24 yr)
		(*Isochrone)[i].L = sigmaSB * pow(10.0, 4.0 * logTeff) * (*Isochrone)[i].A / LSun;
		(*Isochrone)[i].Stage = Stage;
		(*Isochrone)[i].Z = pow(10.0, logZ);
	}
	fclose (InFile);
}
void ReadLamList (char *FileName, double *Spectrum)
{
	int i;
	FILE *InFile;
	
	InFile = fopen (FileName, "r");
	for (i = 0; i < NLam; i++) {fscanf (InFile, "%le\n", &(Spectrum[i]));} // printf ("%d %e\n", i, Spectrum[i]);}
	fclose (InFile);
}

void ReadSpectrum (char *FileName, double *Spectrum)
{
	int i;
	double lam;
	FILE *InFile;
	
	InFile = fopen (FileName, "r");
	for (i = 0; i < NLam; i++) fscanf (InFile, "%le %le\n", &lam, &(Spectrum[i]));
	fclose (InFile);
}

double BnuPlanck (double lambda, double T)
{
	double nu = c / lambda;
	double x = hPlanck * nu / (kB * T);
	
	if (x > 50.0) {return 0.0;}
	if (x <= 1e-6)
	{
		return 2.0 * kB * T / (lambda * lambda);
	}
	return 2.0 * hPlanck * nu / (lambda * lambda) / (exp(x) - 1.0);
}

double FnuPlanck (double lambda, double T) 
{
	double nu = c / lambda;
	double x = hPlanck * nu / (kB * T);
	
	if (x > 50.0) {return 0.0;}
	if (x <= 1e-6)
	{
		return 2.0 * pi * kB * T / (lambda * lambda);
	}

	return 2.0 * pi * hPlanck * nu / (lambda * lambda) / (exp(x) - 1.0);
}

int BinarySearchForFirstGTE (int N, double *Table, double x)
{
    int iLo, iHi, iMid;

    iLo = 0;
    iHi = N - 1;
    while (iHi - iLo > 1)
    {
       //This prevents overflows when iHi + iLo > 32767.
       iMid = iLo + (iHi - iLo) / 2;
       if (x <= Table[iMid]) {iHi = iMid;} else {iLo = iMid;}
    }
    return iHi;
}

double MBol (double LBol)
{
	double LBol0 = 3.0128e28 * Watt; //IAU definition
	return -2.5 * log10(LBol / LBol0);
}

void ReadFilterN0 (char *FileName, int *NFLam, double **Lambda, double **N0)
{
	int i;
	FILE *InFile;

	InFile = fopen (FileName, "r");
	
	*NFLam = CountLinesInFile(InFile);
	//printf ("%d\n", *NFLam);
	*Lambda = calloc (*NFLam, sizeof(double));
	*N0 = calloc (*NFLam, sizeof(double));
	
	for (i = 0; i < *NFLam; i++) fscanf (InFile, "%le %le\n", &((*Lambda)[i]), &((*N0)[i])); 
	fclose (InFile);
}

double InterpolatedN0 (double lambda, int NFLam, double *FilterLambda, double *FilterN0)
{
	int i;
	double N0;

	//printf ("%e  %e %e  %d\n", lambda, FilterLambda[0], FilterLambda[NFLam - 1], BinarySearchForFirstGTE (NFLam, FilterLambda, lambda));
	if (lambda < FilterLambda[0]) {return 0.0;}
	if (lambda > FilterLambda[NFLam - 1]) {return 0.0;}
	
	i = BinarySearchForFirstGTE (NFLam, FilterLambda, lambda);

	N0 = ((lambda - FilterLambda[i - 1]) * FilterN0[i] + (FilterLambda[i] - lambda) * FilterN0[i - 1]) / (FilterLambda[i] - FilterLambda[i - 1]);
	
	return N0;
}

void PrintHeader (FILE *OutFile, char ColumnNames[NFilt][100])
{
	int j;
	fprintf (OutFile, "#log10(t)\t M0 \tlog10(L) \tM_Bol(Obs)");
	for (j = 0; j < NFilt; j++) fprintf (OutFile, " \t%s", ColumnNames[j]);
	fprintf (OutFile, "\n");
}