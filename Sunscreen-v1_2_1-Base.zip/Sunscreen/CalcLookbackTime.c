#include <stdlib.h>
#include <stdio.h>
#include <math.h>

double pi = 3.14159265358979323846264;
double c = 2.998e10;
double G_N = 6.674e-8;
double sigma_SB = 5.671e-5;
double km = 1e5;
double yr = 3.1557e7;
double Mpc = 3.0857e24;
double TCMB = 2.73;

double rho_c (double H0);
double Omega_CMB (double H0, double T);

int main (int argc, char *argv[]) 
{
	int i;
	int NSteps = 1000000;
	double z;
	double dz;

	double zPrimeLo, zPrimeHi;
	double zPrimeLoP1, zPrimeHiP1;
	double EzLo, EzHi;
	
	double Omega_R;// = Omega_CMB(TCMB);
	double Omega_M;
	double Omega_L;// = 1.0 - Omega_M - Omega_R;
	
	double H0;
	double tH; // = 1.0 / H0;
	
	double tL;
	
	if (argc < 4) {printf ("Insufficient arguments. (argc = %d).\n", argc); return 1;}
	z = atof (argv[1]);
	if (z == 0.0) {printf ("%e\n", 0.0); return 0;}
	if (z < 0.0) {printf ("Negative z not allowed.\n"); return 2;}
	Omega_M = atof (argv[2]);
	H0 = atof (argv[3]) * km / Mpc;
	
	tH = 1.0 / H0;
	Omega_R = Omega_CMB (H0, TCMB);
	Omega_L = 1.0 - Omega_M - Omega_R;
	dz = z / NSteps;
	//printf ("%e %e %e  %e  %e\n", Omega_L, Omega_M, Omega_R, tH / yr, dz);
	
	tL = 0.;
	
	for (i = 0; i < NSteps; i++)
	{
		zPrimeLo = (double) i * dz;
		zPrimeHi = zPrimeLo + dz;
		
		zPrimeLoP1 = zPrimeLo + 1.0;
		EzLo = sqrt(Omega_L + Omega_M * zPrimeLoP1 * zPrimeLoP1 * zPrimeLoP1 + Omega_R * zPrimeLoP1 * zPrimeLoP1 * zPrimeLoP1 * zPrimeLoP1);
		zPrimeHiP1 = zPrimeHi + 1.0;
		EzHi = sqrt(Omega_L + Omega_M * zPrimeHiP1 * zPrimeHiP1 * zPrimeHiP1 + Omega_R * zPrimeHiP1 * zPrimeHiP1 * zPrimeHiP1 * zPrimeHiP1);
		
		tL += 0.5 * dz * tH * (1.0 / (zPrimeLoP1 * EzLo) + 1.0 / (zPrimeHiP1 * EzHi));
	}
	printf ("%e\n", tL / yr);
	return 0;
}

double rho_c (double H0) {return 3.0 * H0 * H0 / (8.0 * pi * G_N);}

double Omega_CMB (double H0, double T)
{
	double u_CMB = (sigma_SB * T * T * T * T) * 4.0 / c;
	return u_CMB / (rho_c (H0) * c * c);
}