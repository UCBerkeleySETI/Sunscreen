#!/bin/sh

t0=$(../CalcLookbackTime 1000.0 0.315 67.31)

InFile="RawM15-logMJAM+11.0.txt"
OutFile="M15-MJAM+11.0.txt"

#M15 does NOT give the actual SFR.  What's labeled as "SFR" (or more commonly SFH)
#is actually the rate at which the PRESENT stellar mass has built up.  
#I use the Leither+11 Chabrier conversion to get back to birth mass from present mass.

#t is stellar age; t0 (in the raw file) is lookback time.
tac $InFile | awk '{t = '$t0' - $1 * 1e9; fLoss = 0.046 * log($1 * 1e9 / 2.76e5 - 1.); SFR = $2 / (1 - fLoss); printf "%e %e\n", '$t0' - $1 * 1e9, SFR;}' > $OutFile
