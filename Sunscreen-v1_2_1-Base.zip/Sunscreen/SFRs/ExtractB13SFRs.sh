#!/bin/sh

log10MhList="11.0 12.0 13.0 14.0 15.0"
Omegam="0.315"
H0="67.31"
t0=$(../CalcLookbackTime 1000.0 $Omegam $H0)

for log10Mh in $log10MhList
do
	echo $log10Mh
	#After looking at section 5.1 of Behroozi+13, I think the difference between the "sfr" and "sfh"
	#is that "sfr" describes the SFR in a halo with mass M_h already at each redshift, while "sfh"
	#describes the SFH in a halo with mass M_h at z = 0 (or technically 0.1).  A halo that has mass
	#10^12 M_sun at z = 5, for example, is going to be MUCH bigger at z = 0, so the values in "sfr"
	#do NOT describe the evolution of individual galaxies.  So it's "sfh" that we want.
	#The "sfh" appear to correspond to the RIGHT panel of Figure 6.
	#I assume that the SFRs in "sfh" are physical, instantaneous SFRs, and include stars that have
	#ended their lives by z = 0.	
	InFile=$(printf "release-sfh_z0_z8_052913/sfh/sfh_z0.1_corrected_%.1f.dat" $log10Mh)
	OutFile=$(printf "B13-log10Mh+%.1f.txt" $log10Mh)
	cat $InFile | awk '{z = 1.0 / $1 - 1.0; if (z < 0.0) {z = 0.0;} tmp = sprintf ("../CalcLookbackTime %f '$Omegam' '$H0'", z); tmp | getline tL; printf "%e %e\n", '$t0' - tL, $2;}' > $OutFile
	#| tee $OutFile
done
