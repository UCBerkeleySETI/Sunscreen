#!/bin/bash

CumulSFHFile="RawW14-dIrr-CumulSFH.txt"
OutFile="W14-dIrr.txt"

MScale="1e8"
tMaxGyr="14"
tAge=$(../CalcLookbackTime 1000.0 0.315 67.31)
tScale="1.0"

t0GyrList=$(awk 'BEGIN{for (t = 0; t <= '$tMaxGyr' + 1e-9; t += 1.0){print t}}' | tac)

if [ -e "$OutFile" ]
then
	rm $OutFile
fi

for t0Gyr in $t0GyrList
do
	tLGyr=$(awk 'BEGIN{t = '$t0Gyr'; if (t >= 0.5){print t - 0.5;} else {print 0.0};}')
	tHGyr=$(awk 'BEGIN{t = '$t0Gyr'; tMax = '$tMaxGyr'; if (t <= tMax - 0.5){print t + 0.5;} else {print tMax}}')
	
	tLArray1=( `awk 'BEGIN{print -0.001, 1.0;}($1 < '$tLGyr'){print}' $CumulSFHFile | tail -n 1` )
	tLArray2=( `awk '($1 >= '$tLGyr'){print}' $CumulSFHFile | head -n 1` )
	
	tHArray1=( `awk '($1 < '$tHGyr'){print}' $CumulSFHFile | tail -n 1` )
	tHArray2=( `awk '($1 >= '$tHGyr'){print}END{print '$tMaxGyr' + 0.001, 0.0;}' $CumulSFHFile | head -n 1` )
	
	
	#f = f1 + (t - t1) * (f2 - f1)/(t2 - t1) 
	#f = f2 + (t - t2) * (f1 - f2)/(t1 - t2)
	#f = [f1 * (t2 - t) + f2 * (t - t1)] / (t2 - t1)
	
	fL=$(awk 'BEGIN{t = '$tLGyr'; t1 = '${tLArray1[0]}'; f1 = '${tLArray1[1]}'; t2 = '${tLArray2[0]}'; f2 = '${tLArray2[1]}'; f = (f1 * (t2 - t) + f2 * (t - t1))/(t2 - t1); print f}')
	fH=$(awk 'BEGIN{t = '$tHGyr'; t1 = '${tHArray1[0]}'; f1 = '${tHArray1[1]}'; t2 = '${tHArray2[0]}'; f2 = '${tHArray2[1]}'; f = (f1 * (t2 - t) + f2 * (t - t1))/(t2 - t1); print f}')	
	SFR=$(awk 'BEGIN{SurvivingSFR =  -('$fL' - '$fH') / ('$tLGyr' - '$tHGyr') * '$MScale' / 1e9; tGyr = 0.5 * ('$tHGyr' + '$tLGyr'); fLoss = 0.046 * log(tGyr * 1e9 / 2.76e5 - 1.); print SurvivingSFR / (1. - fLoss);}')
	

	awk 'BEGIN{printf "%e %e\n", ('$tAge'/1e9 - '$t0Gyr') * 1e9, '$SFR'}' | tac | tee -a $OutFile
	
	
	

done


