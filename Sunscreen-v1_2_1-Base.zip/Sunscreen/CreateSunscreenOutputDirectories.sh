#!/bin/sh
#These have to be the same as in Sunscreen-SynthesizePopulationSpectra.c

QuantityList="Small Large"
ThreshList="logL logLtoM0 logM0"
logZList="-1.0 0.0 0.301"
IMFList="Chabrier Salpeter BottomHeavy Chabrier_MinM_1 Chabrier_MinM_2 Chabrier_MinM_5"

for q in $QuantityList
do
	for Thresh in $ThreshList
	do
		OuterDirName=$(printf "%s_%s_Screened_Results" "$q" "$Thresh")
		if [ ! -d "$OuterDirName" ]
		then
			mkdir "$OuterDirName"
		fi
	
		echo "$OuterDirName"
		cd "$OuterDirName"
		
		for logZ in $logZList
		do
			MidDirName=$(printf "logZ%+.2f" "$logZ")
			if [ ! -d "$MidDirName" ]
			then
				mkdir "$MidDirName"
			fi
	
			echo " $MidDirName"
			cd "$MidDirName"
		
			for IMF in $IMFList
			do
				InnerDirName=$(printf "%s" "$IMF")
				if [ ! -d "$InnerDirName" ]
				then
					mkdir "$InnerDirName"
				fi
				echo "  $InnerDirName"
			done
			
			cd ..
		done
		
		cd ..
	done
done

QuantityList="Only AllExcept"
ThreshList="Stage"
for q in $QuantityList
do
	for Thresh in $ThreshList
	do
		OuterDirName=$(printf "%s_%s_Unscreened_Results" "$q" "$Thresh")
		if [ ! -d "$OuterDirName" ]
		then
			mkdir "$OuterDirName"
		fi
	
		echo "$OuterDirName"
		cd "$OuterDirName"
		
		for logZ in $logZList
		do
			MidDirName=$(printf "logZ%+.2f" "$logZ")
			if [ ! -d "$MidDirName" ]
			then
				mkdir "$MidDirName"
			fi
	
			echo " $MidDirName"
			cd "$MidDirName"
		
			for IMF in $IMFList
			do
				InnerDirName=$(printf "%s" "$IMF")
				if [ ! -d "$InnerDirName" ]
				then
					mkdir "$InnerDirName"
				fi
				echo "  $InnerDirName"
			done
			
			cd ..
		done
		
		cd ..
	done
done

OuterDirName=$(printf "UnscreenedResults" $q $Thresh)
if [ ! -d "$OuterDirName" ]
then
	mkdir "$OuterDirName"
fi

echo "$OuterDirName"
cd "$OuterDirName"

for logZ in $logZList
do
	MidDirName=$(printf "logZ%+.2f" "$logZ")
	if [ ! -d "$MidDirName" ]
	then
		mkdir "$MidDirName"
	fi

	echo " $MidDirName"
	cd "$MidDirName"

	for IMF in $IMFList
	do
		InnerDirName=$(printf "%s" "$IMF")
		if [ ! -d "$InnerDirName" ]
		then
			mkdir "$InnerDirName"
		fi
		echo "  $InnerDirName"
	done
	
	cd ..
done

cd ..

if [ ! -d "StellarPopulations" ]
then
	mkdir "StellarPopulations"
fi